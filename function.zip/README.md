# dynamo-delete-lab18
Lab 18 Delete
